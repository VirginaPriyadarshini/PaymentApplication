package com.payment.portal.PaymentPortalApplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.payment.portal.PaymentPortalApplication.Entities.Insurer;
import com.payment.portal.PaymentPortalApplication.Exception.InsurerException;
import com.payment.portal.PaymentPortalApplication.service.InsurerService;


@RestController
public class InsurerController {
	
	@Autowired
	InsurerService insurerService;
	
	 @PostMapping("/createInsurer")
	 public void createInsurer(@RequestBody Insurer insurer) throws InsurerException {
		insurerService.createInsurer(insurer);
	 }
	 
	 
	 @GetMapping("/insurers")
	 public List<Insurer> searchAllInsurers() throws InsurerException {
	     return insurerService.getAllInsurers();
	 }
	 
	 
	 @GetMapping("/insurer/{id}") 
	 private Insurer getInsurerById(@PathVariable("id") int id) throws InsurerException   
	 {  
	 return insurerService.getInsurerById(id); 
	 }  
	 
	
	 @PutMapping("/insurerupdate/{id}")
	 public ResponseEntity<Insurer> updateInsurer(@PathVariable int id, @RequestBody Insurer insurer) throws InsurerException{
		 
		 insurer.setId(id);
		 return ResponseEntity.ok().body(this.insurerService.updateInsurer(insurer));
	 }
	 
	 
	 @DeleteMapping("/insurerdelete/{id}")
	 public void deleteInsurer(@PathVariable int id) throws InsurerException {
		 insurerService.deleteInsurer(id);
	 }
	 
	


}
