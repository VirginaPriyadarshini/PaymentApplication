package com.payment.portal.PaymentPortalApplication.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.payment.portal.PaymentPortalApplication.Entities.Insurer;
import com.payment.portal.PaymentPortalApplication.Exception.InsurerException;
import com.payment.portal.PaymentPortalApplication.repositories.InsurerRepository;

@Service
@Transactional
public class InsurerService {

	@Autowired
	InsurerRepository insurerRepository;
	
	 public void createInsurer(Insurer insurer) throws InsurerException {
		 insurerRepository.save(insurer);
	    }
	 
	 public List<Insurer> getAllInsurers() throws InsurerException {
	        return insurerRepository.findAll();
	 }
	 public Insurer getInsurerById(int id) throws InsurerException{
	        return insurerRepository.findById(id).get();
	    }
	     
	 public void deleteInsurer(int id) throws InsurerException {
		 insurerRepository.deleteById(id);
	    }
	 public Insurer updateInsurer(Insurer insurer) throws InsurerException {
	    	
	    	Optional<Insurer> insurerDb = this.insurerRepository.findById(insurer.getId());
	    	if(insurerDb.isPresent()) {
	    		
	    		Insurer insurerUpdate = insurerDb.get();
	    		insurerUpdate.setId(insurer.getId());
	    		insurerUpdate.setName(insurer.getName());
	    		insurerUpdate.setAge(insurer.getAge());
	    		insurerUpdate.setEmailId(insurer.getEmailId());
	    		insurerUpdate.setGender(insurer.getGender());
	    		insurerUpdate.setAddress(insurer.getAddress());
	    		insurerUpdate.setAmountInsured(insurer.getAmountInsured());
	    		insurerUpdate.setMonthyPremium(insurer.getMonthyPremium());
	    		insurerUpdate.setPhoneNumber(insurer.getPhoneNumber());
	    		insurerUpdate.setPaymentStatus(insurer.getPaymentStatus());
	    		insurerUpdate.setPolicyNumber(insurer.getPolicyNumber());
	    		insurerRepository.save(insurerUpdate);
	    		return insurerUpdate;
	    	}else {
	    		throw new InsurerException("Insurer not found with id:" +insurer.getId());
	    	}
	    }
	


}
