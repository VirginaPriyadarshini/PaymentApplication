package com.payment.portal.PaymentPortalApplication.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.payment.portal.PaymentPortalApplication.Entities.Insurer;

@Repository
public interface InsurerRepository extends JpaRepository<Insurer,Integer> {

}
